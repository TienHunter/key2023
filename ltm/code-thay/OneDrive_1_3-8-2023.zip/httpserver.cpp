#include <pthread.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <malloc.h>
#include <stdlib.h>
#include <dirent.h>
#include <netinet/in.h>
#include <netinet/tcp.h>

typedef struct sockaddr SOCKADDR;
typedef struct sockaddr_in SOCKADDR_IN;
char* rootPath = NULL;
char* html = NULL;

void Send(int c, char* data, int len)
{
    int sent = 0;
    while (sent < len)
    {
        int tmp = send(c, data + sent, len - sent, 0);
        if (tmp > 0)
        {
            sent += tmp;
        }else
            break;
    }
}

int my_filter(const struct dirent * arg)
{
    if (arg->d_type == DT_REG || arg->d_type == DT_DIR)
        return 1;
    else
        return 0;
}

int my_compare(const struct dirent **arg1, const struct dirent ** arg2)
{
    if ((*arg1)->d_type == (*arg2)->d_type) 
        return strcmp((*arg1)->d_name, (*arg2)->d_name);
    else if ((*arg1)->d_type == DT_DIR)
        return -1;
    else
        return 1;
}

void append(char** phtml, const char* str)
{
    char* localhtml = *phtml;
    int oldLen = localhtml == NULL ? 0 : strlen(localhtml);
    int newLen = oldLen + strlen(str) + 1;
    localhtml = (char*)realloc(localhtml, newLen * sizeof(char));
    memset(localhtml + oldLen, 0, (newLen - oldLen) * sizeof(char));
    sprintf(localhtml + oldLen, "%s", str);
    *phtml = localhtml;
}

void MakeContent()
{
    struct dirent** result = NULL;
    int n = scandir(rootPath, &result, my_filter, my_compare);
    append(&html,"<html>");
    for (int i = 0;i < n;i++)
    {
        if (result[i]->d_type == DT_DIR)
        {
            append(&html,"<a href = \"");      
            append(&html,rootPath);
            if (rootPath[strlen(rootPath) - 1] != '/')
            {
                append(&html,"/");
            }  
            append(&html,result[i]->d_name);
            append(&html,"\"><b>");
            append(&html,result[i]->d_name);
            append(&html,"</b></a><br>\n");
        }else if (result[i]->d_type == DT_REG)
        {
            append(&html,"<a href = \"");  
            append(&html,rootPath);
            if (rootPath[strlen(rootPath) - 1] != '/')
            {
                append(&html,"/");
            }      
            append(&html,result[i]->d_name);
            append(&html, "*");
            append(&html,"\"><i>");
            append(&html,result[i]->d_name);
            append(&html,"</i></a><br>\n");
        }
        free(result[i]);
        result[i] = NULL;
    }
    append(&html, "<BR><BR>");
    append(&html, "<H>FILE UPLOADING FORM<BR>");
    append(&html, "<form action=\"");
    append(&html,rootPath);
    append(&html,"\" method=\"POST\" enctype=\"multipart/form-data\">");
    append(&html,"<label>Select file to upload: </label>");
    append(&html,"<input type=\"file\" name=\"file1\"><BR>");
    append(&html,"<label>Select file to upload: </label>");
    append(&html,"<input type=\"file\" name=\"file2\"><BR>");
    append(&html,"<input type=\"submit\" value=\"Upload\">");
    append(&html,"</form>");
    append(&html, "</html>");
}

char* FindBoundary(char* data, int length, char* boundary)
{
    for (int i = 0;i < length;i++)
    {
        if (data[i] == boundary[0])
        {
            int j = 0;
            for (j = 0; j < strlen(boundary);j++)
            {
                if (data[i + j] != boundary[j])
                {
                    break;
                }
            } 
            if (j == strlen(boundary))
            {
                return data + i;
            }       
        }
    }
    return NULL;
}

void* ClientThread(void* arg)
{
    int c = *((int*)arg);
    free(arg);
    arg = NULL;
    char* buffer = NULL;
    while (0 == 0)
    {
        char tmp;
        int r = recv(c, &tmp, 1, 0);
        if (r > 0)
        {
            int size = buffer == NULL? 0 : strlen(buffer);
            buffer = (char*)realloc(buffer, size + 2);
            buffer[size] = tmp;
            buffer[size + 1] = 0;
            if (strstr(buffer, "\r\n\r\n") != NULL)
            {
                break;
            }
        }else
            break;
    }
    if (buffer != NULL && strlen(buffer) > 0)
    {
        char method[16] = { 0 };
        char path[1024] = { 0 };
        sscanf(buffer, "%s%s",method, path);
        if (strstr(method,"GET"))
        {
            while (strstr(path,"%20") != NULL)
            {
                char tmp[1024] = { 0 };
                char* start = strstr(path, "%20");
                strncpy(tmp, path, start - path);
                sprintf(tmp + strlen(tmp), " %s", start + 3);
                strcpy(path, tmp);
            }

            if (strcmp(path,"/") == 0)
            {
                const char* header = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n";
                Send(c, (char*)header, strlen(header));
                MakeContent();
                Send(c, html, strlen(html));
                free(html);
                html = NULL;
                close(c);
            }else
            {
                if (strcmp(path,"/favicon.ico") == 0)
                {
                    FILE* f = fopen("/mnt/e/WSL/fav.ico","rb");
                    if (f != NULL)
                    {
                        const char* header = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n";
                        Send(c, (char*)header, strlen(header));
                        fseek(f, 0, SEEK_END);
                        int size = ftell(f);
                        fseek(f, 0, SEEK_SET);
                        char* data = (char*)calloc(size, sizeof(char));
                        fread(data, 1, size, f);
                        Send(c, data, size);
                        close(c);
                        fclose(f);    
                    }else
                    {
                        const char* header = "HTTP/1.1 404 NOT FOUND\r\nContent-Type: text/html\r\n\r\n";
                        Send(c, (char*)header, strlen(header));
                        const char* notfound = "<html>RESOURCE NOT FOUND</html>";
                        Send(c, (char*)notfound, strlen(notfound));
                        close(c);  
                    }
                }else if (path[strlen(path) - 1] == '*')
                {
                    path[strlen(path) - 1] = 0;
                    FILE* f = fopen(path,"rb");
                    if (f != NULL)
                    {
                        char header[1024] = {0};
                        if (strstr(path,".txt") != NULL)
                            strcpy(header, "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n");
                        else if (strstr(path,".wav") != NULL)    
                            strcpy(header, "HTTP/1.1 200 OK\r\nContent-Type: audio/wav\r\n\r\n");
                        else if (strstr(path,".pdf") != NULL)    
                            strcpy(header, "HTTP/1.1 200 OK\r\nContent-Type: application/pdf\r\n\r\n");
                        else
                            strcpy(header, "HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\n\r\n");

                        Send(c, (char*)header, strlen(header));
                        fseek(f, 0, SEEK_END);
                        int size = ftell(f);
                        fseek(f, 0, SEEK_SET);
                        char* data = (char*)calloc(size, sizeof(char));
                        fread(data, 1, size, f);
                        Send(c, data, size);
                        close(c);
                        fclose(f);    
                    }else
                    {
                        const char* header = "HTTP/1.1 404 NOT FOUND\r\nContent-Type: text/html\r\n\r\n";
                        Send(c, (char*)header, strlen(header));
                        const char* notfound = "<html>RESOURCE NOT FOUND</html>";
                        Send(c, (char*)notfound, strlen(notfound));
                        close(c);  
                    }
                }else 
                {
                    const char* header = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n";
                    Send(c, (char*)header, strlen(header));
                    rootPath = (char*)realloc(rootPath, strlen(path) + 1);
                    strcpy(rootPath, path);
                    MakeContent();
                    Send(c, html, strlen(html));
                    free(html);
                    html = NULL;
                    close(c);
                }
            }        
        }else if (strstr(method,"POST"))
        {
            while (strstr(path,"%20") != NULL)
            {
                char tmp[1024] = { 0 };
                char* start = strstr(path, "%20");
                strncpy(tmp, path, start - path);
                sprintf(tmp + strlen(tmp), " %s", start + 3);
                strcpy(path, tmp);
            }

            int length = 0;
            char* ct = strstr(buffer, "Content-Length: ");
            sscanf(ct + strlen("Content-Length: "),"%d", &length);
            char* data = (char*)calloc(length, 1);
            int r = 0;
            while (r < length)
            {
                int tmp = recv(c, data + r, length - r, 0);
                if (tmp > 0)
                {
                    r += tmp;
                }else
                    break;
            }
            char* bd = strstr(buffer, "boundary=");
            char boundary[1024] = { 0 };
            sscanf(bd + strlen("boundary="),"%s",boundary);
            char* start = data;
            while (0 == 0)
            {
                int offset = data - start;
                start = FindBoundary(start, length - offset, boundary);
                if (start != NULL)
                {
                    char* fnStart = strstr(start, "filename=\"");
                    if (fnStart != NULL)
                    {
                        fnStart += strlen("filename=\"");
                        char* fnEnd = strstr(fnStart, "\"");        
                        char filename[1024] = { 0 };
                        strncpy(filename, fnStart, fnEnd - fnStart);
                        char* fileDataStart = strstr(start, "\r\n\r\n") + 4;
                        char* fileDataEnd = FindBoundary(start + 1, length - offset - 1, boundary);
                        while (strncmp(fileDataEnd, "\r\n", 2) != 0)
                        {
                            fileDataEnd -= 1;
                        }
                        char absoluePath[4096] = { 0 };
                        if (path[strlen(path) - 1] != '/')
                            sprintf(absoluePath, "%s/%s", path, filename);
                        else
                            sprintf(absoluePath, "%s%s", path, filename);

                        FILE* f = fopen(absoluePath, "wb");
                        fwrite(fileDataStart, 1, fileDataEnd - fileDataStart, f);
                        fclose(f);

                        start = fileDataEnd;
                    }else
                    {
                        break;
                    }
                }
            }
            free(data);
            data = NULL;        

            const char* header = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n";
            Send(c, (char*)header, strlen(header));
            const char* okay = "<html>UPLOADING COMPLETED</html>";
            Send(c, (char*)okay, strlen(okay));
            close(c);          
        }
        free(buffer);
        buffer = NULL;
    }
    return NULL;
}
int main()
{
    rootPath = (char*)calloc(2, sizeof(char));
    strcpy(rootPath,"/");

    SOCKADDR_IN myaddr, caddr;
    int clen = sizeof(caddr);
    myaddr.sin_family = AF_INET;
    myaddr.sin_port = htons(5000);
    myaddr.sin_addr.s_addr = 0;
    int s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    bind(s, (SOCKADDR*)&myaddr, sizeof(myaddr));
    listen(s, 10);
    while (0 == 0)
    {
        int c = accept(s, (SOCKADDR*)&caddr, (socklen_t*)&clen);
        int* arg = (int*)calloc(1, sizeof(int));
        *arg = c;
        pthread_t tid;
        pthread_create(&tid, NULL, ClientThread, (void*)arg);
    }
}